package com.example.jiyoon.threadtest1;

import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    int mCount = 0;
    int mCount2= 0;
    TextView mCountTextView = null;
    TextView mCountTextView2 = null;
    Handler mHandler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mCountTextView=(TextView)findViewById(R.id.textView);
        mCountTextView2=(TextView)findViewById(R.id.textView2);
        Thread countThread = new Thread("Count Thread") {
            public void run() {
                for (int i = 0; i < 10; i++) {
                    mCount++;
                    mHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            Log.i("superdroid", "count : " + mCount);
                            mCountTextView.setText("Count :" + mCount);
                        }
                    });

                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                }
            }
        };
        Thread countThread2 = new Thread("Count Thread2") {
            public void run() {
                for (int i = 0; i < 10; i++) {
                    mCount2++;
                    mHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            Log.i("superdroid2", "count2 : " + mCount2);
                            mCountTextView2.setText("Count2 :" + mCount2);
                        }
                    });

                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                }
            }
        };
        countThread.start();
        countThread2.start();

    }
}